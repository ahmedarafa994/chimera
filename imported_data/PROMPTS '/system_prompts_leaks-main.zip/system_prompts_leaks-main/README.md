![image](https://github.com/user-attachments/assets/ccd777ea-2a39-48de-9524-f8bc27872e7c)


# System Prompts Leaks

Collection of system message instructions for various publicly deployed chatbots.

I try to cite all sources when the source someone other than myself.

Feel free to do PR's.

Please use discussions tabs for discussions not the Issues tab.


Contact Info:

email: asgeirtj at gmail.com  
Discord username: asgeirtj  
X profile: https://x.com/asgeirtj  
reddit: https://www.reddit.com/user/StableSable/  

[![Ask DeepWiki](https://deepwiki.com/badge.svg)](https://deepwiki.com/asgeirtj/system_prompts_leaks)
